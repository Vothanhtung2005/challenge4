package com.example.challenge4;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class SportAdapter extends RecyclerView.Adapter<SportAdapter.SportViewHolder> {

    private Context context;
    private List<Sport> sportList;

    public SportAdapter(Context context, List<Sport> sportList) {
        this.context = context;
        this.sportList = sportList;
    }

    @Override
    public SportViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_sport_card, parent, false);
        return new SportViewHolder(view);
    }

    @Override
    public void onBindViewHolder(SportViewHolder holder, int position) {
        Sport sport = sportList.get(position);
        holder.textView.setText(sport.getName());
        holder.imageView.setImageResource(sport.getImageResId());
    }

    @Override
    public int getItemCount() {
        return sportList.size();
    }

    public class SportViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView textView;

        public SportViewHolder(View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.sportImage);
            textView = itemView.findViewById(R.id.sportName);
        }
    }
}
