package com.example.challenge4;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private SportAdapter adapter;
    private List<Sport> sportList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        sportList = new ArrayList<>();
        sportList.add(new Sport("Basketball", R.drawable.basketball));
        sportList.add(new Sport("Volleyball", R.drawable.volleyball));
        sportList.add(new Sport("Tennis", R.drawable.tennis));
        // Thêm ảnh và tên môn thể thao khác nếu cần

        adapter = new SportAdapter(this, sportList);
        recyclerView.setAdapter(adapter);
    }
}
